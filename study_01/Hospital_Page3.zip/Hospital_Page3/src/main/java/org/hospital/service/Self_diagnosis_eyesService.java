package org.hospital.service;

public interface Self_diagnosis_eyesService {

}
