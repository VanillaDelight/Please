package org.hospital.domain;

public class Self_diagnosis_eyesVO {

}
