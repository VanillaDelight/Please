package org.hospital.mapper;

public interface Self_diagnosis_eyesMapper {

}
