package org.hospital.controller;

public class Self_diagnosis_eyesController {

}
