package org.hospital.controller;

public class HospitalsControllerTests {

}
