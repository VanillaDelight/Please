package org.hospital.persistence;

public class TimeMapperTests {

}
