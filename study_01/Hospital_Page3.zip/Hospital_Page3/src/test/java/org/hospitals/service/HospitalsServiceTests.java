package org.hospitals.service;

public class HospitalsServiceTests {

}
